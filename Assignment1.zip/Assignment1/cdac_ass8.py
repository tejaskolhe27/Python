n=int(input("Enter a number: "))
last=n%10
if last%3==0:
    print("Divisible by 3")
else:
    print("Not divisible by 3")